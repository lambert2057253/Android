package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.ContextMenu;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.myapplication.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    private TextView txtv1,txtv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        FloatingActionButton fab=(FloatingActionButton) findViewById(R.id.fab);
        txtv1=(TextView)findViewById(R.id.textview_second);
        txtv2=(TextView)findViewById(R.id.textView);
        registerForContextMenu(txtv1);
        registerForContextMenu(txtv2);
    }
    protected static final int MENU_BLACKCOLOR= Menu.FIRST;
    protected static final int MENU_WHITCOLOR=Menu.FIRST+1;
    protected static final int MENU_SMALLSIZE=Menu.FIRST+2;
    protected static final int MENU_LARGESIZE=Menu.FIRST+3;
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if(v==txtv1){
            menu.add(0,MENU_BLACKCOLOR,1,"黑色背景顏色");
            menu.add(0,MENU_WHITCOLOR,1,"白色背景顏色");
        }
        else if(v==txtv2){
            menu.add(0,MENU_SMALLSIZE,1,"較小文字");
            menu.add(0,MENU_LARGESIZE,1,"較大文字");
        }
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case MENU_BLACKCOLOR:
                txtv1.setBackgroundColor(Color.BLACK);
                txtv2.setBackgroundColor(Color.BLACK);
                break;
            case MENU_WHITCOLOR:
                txtv1.setBackgroundColor(Color.WHITE);
                txtv2.setBackgroundColor(Color.WHITE);
                break;
            case MENU_SMALLSIZE:
                txtv1.setTextSize(14);
                txtv2.setTextSize(14);
                break;
            case MENU_LARGESIZE:
                txtv1.setTextSize(24);
                txtv2.setTextSize(24);
                break;
        }

        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        /*if (id == R.id.action_settings) {
            return true;
        }*/
        TextView tv=(TextView)findViewById(R.id.textview_first);
        switch (item.getItemId()) {
            case R.id.action_settings:
                tv.setText("這是設定");
                break;
            case R.id.action_about:
                tv.setText("這是關於");
                break;
            case R.id.action_test:
                tv.setText("這是測試");
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}