package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView tv1;
    private Spinner spn1;
    //String[] balls=new String[]{"籃球 Basketball","足球 Football","棒球 Baseball","其他 Others"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1=(TextView) findViewById(R.id.textView2);
        spn1=(Spinner) findViewById(R.id.spinner);

        /*ArrayAdapter<String> adapterball= new ArrayAdapter<String>(this , android.R.layout.simple_dropdown_item_1line,balls);*///需要自己打上面的String
        ArrayAdapter<CharSequence> adapterball = ArrayAdapter.createFromResource(this,R.array.balls, android.R.layout.simple_spinner_dropdown_item);//不用自己打string,但是要在string.xml裡面加入
        adapterball.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn1.setAdapter(adapterball);
        spn1.setOnItemSelectedListener(spnlistneer);
    }

    private AdapterView.OnItemSelectedListener spnlistneer = new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            String str ="你喜歡的運動是 Your favorite sport is : "+adapterView.getSelectedItem().toString();
            tv1.setText(str);
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
            tv1.setText("你沒有喜歡的運動 You don't like any sport.");
        }
    };
}