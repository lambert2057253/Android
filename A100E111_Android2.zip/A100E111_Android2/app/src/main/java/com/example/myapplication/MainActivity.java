package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12;
    private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);
        b5 = (Button) findViewById(R.id.b5);
        b6 = (Button) findViewById(R.id.b6);
        b7 = (Button) findViewById(R.id.b7);
        b8 = (Button) findViewById(R.id.b8);
        b9 = (Button) findViewById(R.id.b9);
        b10 = (Button) findViewById(R.id.b10);
        b11 = (Button) findViewById(R.id.b11);
        b12 = (Button) findViewById(R.id.b12);
        text = (TextView) findViewById(R.id.textView);

        b1.setOnClickListener(buttonclick);
        b2.setOnClickListener(buttonclick);
        b3.setOnClickListener(buttonclick);
        b4.setOnClickListener(buttonclick);
        b5.setOnClickListener(buttonclick);
        b6.setOnClickListener(buttonclick);
        b7.setOnClickListener(buttonclick);
        b8.setOnClickListener(buttonclick);
        b9.setOnClickListener(buttonclick);
        b10.setOnClickListener(buttonclick);
        b11.setOnClickListener(buttonclick);
        b12.setOnClickListener(buttonclick);
    }
    private Button.OnClickListener buttonclick =new Button.OnClickListener() {
        @Override
        public void onClick(View view) {
            String str;
            str= text.getText().toString();

            switch (view.getId()) {
                case R.id.b1:
                    str = str + "1";
                    break;
                case R.id.b2:
                    str = str + "2";
                    break;
                case R.id.b3:
                    str = str + "3";
                    break;
                case R.id.b4:
                    str = str + "4";
                    break;
                case R.id.b5:
                    str = str + "5";
                    break;
                case R.id.b6:
                    str = str + "6";
                    break;
                case R.id.b7:
                    str = str + "7";
                    break;
                case R.id.b8:
                    str = str + "8";
                    break;
                case R.id.b9:
                    str = str + "9";
                    break;
                case R.id.b10:
                    str = str + "*";
                    break;
                case R.id.b11:
                    str = str + "0";
                    break;
                case R.id.b12:
                    str = str + "#";
                    break;
            }
            text.setText(str);
        }
    };
}