package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1=(Button) findViewById(R.id.button);
        btn1.setOnClickListener(change2);

        Button btnweb=(Button) findViewById(R.id.button2);
        Button btndial=(Button) findViewById(R.id.button3);
        Button btncall=(Button) findViewById(R.id.button4);
        btnweb.setOnClickListener(change2);
        btndial.setOnClickListener(change2);
        btncall.setOnClickListener(change2);

        requestPermissions();
    }

    private void requestPermissions() {
        if(Build.VERSION.SDK_INT>=23){
            int hasPermission= ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE);
            if(hasPermission!= PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CALL_PHONE},1);
            }

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==1){
            if(grantResults[0]!=PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"未取得授權",Toast.LENGTH_LONG).show();
            }
            finish();
        }else{
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private View.OnClickListener change2=new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent;
            Uri uri;
            switch(view.getId()){
                case  R.id.button:
                    intent=new Intent();
                    intent.setClass(MainActivity.this,Second.class);
                    startActivity(intent);
                    break;
                case R.id.button2:
                    uri=Uri.parse("http://www.ksu.edu.tw");
                    intent=new Intent(Intent.ACTION_VIEW,uri);
                    startActivity(intent);
                    break;
                case R.id.button3:
                    uri=Uri.parse("tel:0987123456");
                    intent=new Intent(Intent.ACTION_DIAL,uri);
                    startActivity(intent);
                    break;
                case R.id.button4:
                    uri=Uri.parse("tel:0987123456");
                    intent=new Intent(Intent.ACTION_CALL,uri);
                    startActivity(intent);
                    break;
            }

        }
    };
}