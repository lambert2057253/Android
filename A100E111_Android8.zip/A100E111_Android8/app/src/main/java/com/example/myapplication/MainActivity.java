package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    ImageView img;
    GridView gv;
    int pics[]={R.drawable.rabbit1,R.drawable.rabbit2,R.drawable.rabbit3,R.drawable.rabbit4,R.drawable.rabbit5};
    int index=0,count=pics.length;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=(Button) findViewById(R.id.button);
        b2=(Button) findViewById(R.id.button2);
        img=(ImageView) findViewById(R.id.imageView);
        gv=(GridView) findViewById(R.id.gridView);

        MyAdapter adapter=new MyAdapter(this);
        gv.setAdapter(adapter);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                img.setImageResource(pics[i]);
                index=i;
            }
        });

        b1.setOnClickListener(UpDown);
        b2.setOnClickListener(UpDown);
        img.setOnClickListener(UpDown);
    }
    class MyAdapter extends BaseAdapter {
        private Context mycontext;
        public MyAdapter(Context c){
            mycontext=c;
        }

        @Override
        public int getCount() {
            return pics.length;
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ImageView iv=new ImageView(mycontext);
            iv.setImageResource(pics[i]);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setLayoutParams(new ViewGroup.LayoutParams(140,100));
            return iv;
        }
    }



    View.OnClickListener UpDown = new View.OnClickListener() {
        @Override
        public void onClick(View view){
            if(view.getId()==b1.getId()){
                index=(index+count-1)%count;
                img.setImageResource(pics[index]);
                b1.setText("上一張");
                b2.setText("下一張");
            }else if(view.getId()==R.id.button2){
                index=(index+1)%count;
                img.setImageResource(pics[index]);
                b1.setText("上一張");
                b2.setText("下一張");
            }else if(view.getId()==R.id.imageView){
                b1.setText("Click Here");
                b2.setText("Click Here");
            }
        }
        /*public void onClick(View view) {
            if(view.getId()==b1.getId()){
                if(index!=0){
                    index--;
                }
                img.setImageResource(pics[index]);
            }else if(view.getId()==R.id.button2){
                if(index!=(count-1)){
                    index++;
                }
                img.setImageResource(pics[index]);
            }
        }*/
    };
}