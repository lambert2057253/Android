package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private ListView lv;
    private TextView tv,tv2;
    String[] engName =new String[]{"Basketball","Football","Baseball","Badminton"};
    String[] Balls = new String[]{"籃球","足球","棒球","羽毛球"};
    int[] resIds=new int[]{R.drawable.basketball,R.drawable.football,R.drawable.baseball,R.drawable.badminton};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        lv = (ListView) findViewById(R.id.listView);
        tv = (TextView) findViewById(R.id.textView);
        tv2 = (TextView) findViewById(R.id.textView2);
        Myadapter adapter=new Myadapter(this);
        lv.setAdapter(adapter);

        /*ArrayAdapter<String> adapterball = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice,Balls);
        lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        lv.setAdapter(adapterball);

        lv.setSelector(R.drawable.b);
        lv.setTextFilterEnabled(true);

        lv.setOnItemClickListener(boxx);*/
    }
    public class Myadapter extends BaseAdapter{
        private LayoutInflater myInflater;
        public Myadapter(Context c){
            myInflater=LayoutInflater.from(c);
        }

        @Override
        public int getCount() {
            return Balls.length;
        }

        @Override
        public Object getItem(int i) {
            return Balls[i];
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view=myInflater.inflate(R.layout.mylayout,null);
            ImageView imgLogo=(ImageView) view.findViewById(R.id.imageView);
            TextView tv1=(TextView) view.findViewById(R.id.textView);
            TextView tv2=(TextView) view.findViewById(R.id.textView2);

            imgLogo.setImageResource(resIds[i]);
            tv1.setText(Balls[i]);
            tv2.setText(engName[i]);
            return view;
        }
    }
    /*public AdapterView.OnItemClickListener boxx =new AdapterView.OnItemClickListener(){
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            String str = adapterView.getItemAtPosition(i).toString();
            tv.setText("Your favorite sport is:"+str);
            if(lv.isItemChecked(i)){
                setTitle("目前選取"+str);
            }else {
                setTitle("取消選取"+str);
            }
            str="";
            for(int j=0;j<Balls.length;j++){
                if(lv.isItemChecked(j)){
                    str=str+","+Balls[j];
                }
            }
            tv2.setText("你喜歡的運動是 "+str);
        }
    };*/

}