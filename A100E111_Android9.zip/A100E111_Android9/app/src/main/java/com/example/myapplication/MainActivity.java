package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private ListView lv;
    private TextView tv,tv2;
    String[] Balls = new String[]{"籃球","足球","棒球","羽毛球"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        lv = (ListView) findViewById(R.id.listView);
        tv = (TextView) findViewById(R.id.textView);
        tv2 = (TextView) findViewById(R.id.textView2);
        ArrayAdapter<String> adapterball = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice,Balls);
        lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        lv.setAdapter(adapterball);

        lv.setSelector(R.drawable.b);
        lv.setTextFilterEnabled(true);

        lv.setOnItemClickListener(boxx);
    }
    public AdapterView.OnItemClickListener boxx =new AdapterView.OnItemClickListener(){
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            String str = adapterView.getItemAtPosition(i).toString();
            tv.setText("Your favorite sport is:"+str);
            if(lv.isItemChecked(i)){
                setTitle("目前選取"+str);
            }else {
                setTitle("取消選取"+str);
            }
            str="";
            for(int j=0;j<Balls.length;j++){
                if(lv.isItemChecked(j)){
                    str=str+","+Balls[j];
                }
            }
            tv2.setText("你喜歡的運動是 "+str);
        }
    };

}