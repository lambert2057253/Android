package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    RadioButton rbt1,rbt2,rbt3;
    RadioGroup rgp1;
    TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rgp1 = findViewById(R.id.radioGroup);
        rbt1 = findViewById(R.id.radioButton);
        rbt2 = findViewById(R.id.radioButton2);
        rbt3 = findViewById(R.id.radioButton3);
        tv1 = findViewById(R.id.textView2);

        rgp1.setOnCheckedChangeListener(xxx);
    }
    private  RadioGroup.OnCheckedChangeListener xxx= new RadioGroup.OnCheckedChangeListener(){
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int i ) {
            String str="";
            int count=radioGroup.getChildCount();
            if(i==R.id.radioButton){
                str="There are "+count+" sports "+rbt1.getText().toString();
            }
            if(i==R.id.radioButton2){
                str="There are "+count+" sports "+rbt2.getText().toString();
            }
            if(i==R.id.radioButton3){
                str="There are "+count+" sports "+rbt3.getText().toString();
            }
            tv1.setText(str);
        }
    };
}