package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13;
    private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        b4 = (Button) findViewById(R.id.button4);
        b5 = (Button) findViewById(R.id.button5);
        b6 = (Button) findViewById(R.id.button6);
        b7 = (Button) findViewById(R.id.button7);
        b8 = (Button) findViewById(R.id.button8);
        b9 = (Button) findViewById(R.id.button9);
        b10 = (Button) findViewById(R.id.button10);
        b11 = (Button) findViewById(R.id.button11);
        b12 = (Button) findViewById(R.id.button12);
        b13 = (Button) findViewById(R.id.button13);
        text = (TextView) findViewById(R.id.textView);

        b1.setOnClickListener(buttonclick);
        b2.setOnClickListener(buttonclick);
        b3.setOnClickListener(buttonclick);
        b4.setOnClickListener(buttonclick);
        b5.setOnClickListener(buttonclick);
        b6.setOnClickListener(buttonclick);
        b7.setOnClickListener(buttonclick);
        b8.setOnClickListener(buttonclick);
        b9.setOnClickListener(buttonclick);
        b10.setOnClickListener(buttonclick);
        b11.setOnClickListener(buttonclick);
        b12.setOnClickListener(buttonclick);
        b13.setOnClickListener(buttonclick);
    }
    private Button.OnClickListener buttonclick =new Button.OnClickListener() {
        @Override
        public void onClick(View view) {
            String str;
            str= text.getText().toString();

            switch (view.getId()) {
                case R.id.button:
                    str = str + "1";
                    break;
                case R.id.button2:
                    str = str + "2";
                    break;
                case R.id.button3:
                    str = str + "3";
                    break;
                case R.id.button4:
                    str = str + "4";
                    break;
                case R.id.button5:
                    str = str + "5";
                    break;
                case R.id.button6:
                    str = str + "6";
                    break;
                case R.id.button7:
                    str = str + "7";
                    break;
                case R.id.button8:
                    str = str + "8";
                    break;
                case R.id.button9:
                    str = str + "9";
                    break;
                case R.id.button10:
                    if(str.length()>0){
                        str=str.substring(0,str.length()-1);
                    };
                    break;
                case R.id.button11:
                    str = str + "0";
                    break;
                case R.id.button12:
                    String pwd ="123456789";
                    String pw ="987654321";
                    if(pwd.equalsIgnoreCase(str) || pw.equalsIgnoreCase(str)) {
                        Toast toast=Toast.makeText(MainActivity.this,"密碼正確",Toast.LENGTH_LONG);
                        toast.show();
                    }else {
                        Toast toast=Toast.makeText(MainActivity.this,"密碼錯誤",Toast.LENGTH_LONG);
                        toast.show();
                    }
                    break;
                case R.id.button13:
                    //指名的做法
                    AlertDialog.Builder ablg = new AlertDialog.Builder(MainActivity.this);
                        ablg.setTitle("Confirm Widows");
                        ablg.setIcon(R.mipmap.ic_launcher);
                        ablg.setMessage("Are you sur to close this app?????");
                        ablg.show();
                    //暱名的做法
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Confirm Widows")
                            .setIcon(R.mipmap.ic_launcher_round)
                            .setMessage("Are you sur to close this app?")
                            .setPositiveButton("Confirm(確認)", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    finish();
                                }
                            })
                            .setNeutralButton("Cancel(取消)", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                }
                            })
                            .setNegativeButton("Test(測試)", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                }
                            })
                            .show();
                    break;
            }
            text.setText(str);
        }
    };
}