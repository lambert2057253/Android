package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    CheckBox chk1,chk2,chk3,chk4,chk5;
    TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chk1 = findViewById(R.id.checkBox);
        chk2 = findViewById(R.id.checkBox2);
        chk3 = findViewById(R.id.checkBox3);
        chk4 = findViewById(R.id.checkBox4);
        chk5 = findViewById(R.id.checkBox5);
        tv1 = findViewById(R.id.textView2);

        chk1.setOnCheckedChangeListener(sports);
        chk2.setOnCheckedChangeListener(sports);
        chk3.setOnCheckedChangeListener(sports);
        chk4.setOnCheckedChangeListener(sports);
        chk5.setOnCheckedChangeListener(sports);
    }
    private  CompoundButton.OnCheckedChangeListener sports= new CompoundButton.OnCheckedChangeListener(){
        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
            int n=0;
            String str="";
            String s1="",s2="",s3="",s4="",s5="";

            if(chk1.isChecked()){
                n++;
                s1=chk1.getText().toString();
            }else{
                s1="";
            }
            if(chk2.isChecked()){
                n++;
                s2=chk2.getText().toString();
            }else{
                s2="";
            }
            if(chk3.isChecked()){
                n++;
                s3=chk3.getText().toString();
            }else{
                s3="";
            }
            if(chk4.isChecked()){
                n++;
                s4=chk4.getText().toString();
            }else{
                s4="";
            }
            if(chk5.isChecked()){
                n++;
                s5=chk5.getText().toString();
            }else{
                s5="";
            }
            str="The sports you like : "+s1+" "+s2+" "+s3+" "+s4+" "+s5+" "+",total : "+n+"types";
            tv1.setText(str);
        }
    };
}